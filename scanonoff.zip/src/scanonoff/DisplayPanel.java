package scanonoff;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.JPanel;

public class DisplayPanel
  extends JPanel
{
  private static final long serialVersionUID = 1L;
  private boolean on = false;
  private float frequency = 108.0F;
  private String title;
  private Font f1 = new Font("Helvetica", 1, 36);
  private Font f2 = new Font("Times", 3, 24);
  
  public DisplayPanel(String title)
  {
    this.title = title;
    setBackground(Color.green);
  }
  
  public void setValue(float value)
  {
    this.frequency = value;
    repaint();
  }
  
  public boolean isOn()
  {
    return this.on;
  }
  
  public void turnOn()
  {
    this.on = true;
    repaint();
  }
  
  public void turnOff()
  {
    this.on = false;
    repaint();
  }
  
  public void paintComponent(Graphics g)
  {
    g.setColor(Color.green);
    g.fillRect(0, 0, getWidth(), getHeight());
    

    g.setFont(this.f2);
    g.setColor(Color.black);
    FontMetrics fm = g.getFontMetrics();
    int fontWidth = fm.stringWidth(this.title);
    int fontHeight = fm.getHeight();
    int x = (getSize().width - fontWidth) / 2;
    int y = fontHeight;
    g.drawString(this.title, x, y);
    g.drawLine(x, y + 3, x + fontWidth, y + 3);
    

    g.setFont(this.f1);
    g.setColor(Color.red);
    fm = g.getFontMetrics();
    //String content;
    String content;
    if (!this.on) {
      content = "----";
    } else {
      content = String.valueOf(Math.round(this.frequency * 10.0F) / 10.0D) + " MHz";
    }
    fontWidth = fm.stringWidth(content);
    fontHeight = fm.getHeight();
    x = (getSize().width - fontWidth) / 2;
    y = (getSize().height + fontHeight) / 2;
    g.drawString(content, x, y);
  }
}

