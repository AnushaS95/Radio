package scanonoff;


import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class RadioProj
  implements Runnable, ActionListener
{
  private static final int freqTop = 108;
  private static final int freqBottom = 88;
  private float frequency = 108.0F;
  private double[] lockFrequency = { 105.90000000000001D, 101.8D, 98.5D, 95.599999999999994D, 92.099999999999994D };
  private boolean isScanning = false;
  private DisplayPanel display;
  private JButton on;
  private JButton off;
  private JButton scan;
  private JButton reset;
  private volatile Thread searchChannel;
  
  public void init()
  {
    JFrame frame = new JFrame("FM Radio");
    frame.setDefaultCloseOperation(3);
    Container pane = frame.getContentPane();
    
    this.display = new DisplayPanel("FM Radio");
    pane.add(this.display, "Center");
    
    JPanel p = new JPanel();
    this.on = new JButton("on");
    this.on.addActionListener(this);
    p.add(this.on);
    
    this.off = new JButton("off");
    this.off.addActionListener(this);
    p.add(this.off);
    
    this.scan = new JButton("scan");
    this.scan.addActionListener(this);
    p.add(this.scan);
    
    this.reset = new JButton("reset");
    this.reset.addActionListener(this);
    p.add(this.reset);
    
    pane.add(p, "South");
    
    frame.pack();
    frame.setSize(350, 300);
    frame.setVisible(true);
  }
  
  public static void main(String[] argv)
  {
    RadioProj radio = new RadioProj();
    radio.init();
  }
  
  public void actionPerformed(ActionEvent e)
  {
    if (e.getActionCommand().equals("on"))
    {
      this.display.turnOn();
      this.frequency = 108.0F;
      this.display.setValue(this.frequency);
    }
    else if (e.getActionCommand().equals("off"))
    {
      this.display.turnOff();
      
      this.searchChannel = null;
    }
    else if (e.getActionCommand().equals("scan"))
    {
      if (this.display.isOn()) {
        scanning();
      }
    }
    else if ((e.getActionCommand().equals("reset")) && 
      (this.display.isOn()))
    {
      reset();
    }
  }
  
  private void scanning()
  {
    if (!this.isScanning)
    {
      this.searchChannel = new Thread(this);
      this.searchChannel.start();
      this.isScanning = true;
    }
  }
  
  private int checkFreq()
  {  

	  int i = 0; // initialization
	  while (i < 5) { // condition
		  if (Math.abs(this.frequency - this.lockFrequency[i]) < 0.01D) {
		        return i;
		  }
		  i++;
		 //   return -1;
		}
	  return -1;
  }
  
  private void reset()
  {
    this.searchChannel = null;
    this.frequency = 108.0F;
    this.display.setValue(this.frequency);
  }
  
  public void run()
  {
    while ((this.searchChannel != null) && (this.frequency > 88.010000000000005D))
    {
      this.frequency = ((float)(this.frequency - 0.1D));
      this.display.setValue(this.frequency);
      try
      {
        Thread.sleep(100L);
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
      int channelID = checkFreq();
      if (channelID != -1) {
        break;
      }
    }
    this.isScanning = false;
  }
}
